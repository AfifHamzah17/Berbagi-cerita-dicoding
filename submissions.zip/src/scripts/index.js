// CSS imports
import '../styles/styles.css';

import App from './pages/app';

document.addEventListener('DOMContentLoaded', async () => {
  const app = new App({
    content: document.querySelector('#main-content'),
    drawerButton: document.querySelector('#drawer-button'),
    navigationDrawer: document.querySelector('#navigation-drawer'),
  });
  await app.renderPage();

  window.addEventListener('hashchange', async () => {
    await app.renderPage();
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const logoutBtn = document.getElementById('logout-btn');
  if(logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      // Contoh: hapus token di localStorage (ganti sesuai yang kamu pakai)
      localStorage.removeItem('userToken');
      localStorage.removeItem('isLoggedIn');

      // Redirect ke halaman login
      window.location.href = '#/login'; // sesuaikan path login di SPA-mu
    });
  }
});
