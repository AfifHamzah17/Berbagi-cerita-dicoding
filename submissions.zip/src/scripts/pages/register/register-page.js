import { StoryAPI } from '../../data/api.js';

export default class RegisterPage {
  async render() {
    return `
      <section class="container">
        <h1>Register</h1>
        <form id="register-form">
          <label for="name">Nama</label>
          <input id="name" type="text" required />

          <label for="email">Email</label>
          <input id="email" type="email" required />

          <label for="password">Password</label>
          <input id="password" type="password" minlength="8" required />

          <button type="submit">Daftar</button>
        </form>
        <div class="auth-switch">
          <button id="to-login">Sudah punya akun? Masuk di sini</button>
        </div>
        <div id="register-status"></div>
      </section>
    `;
  }

  async afterRender() {
    const form = document.getElementById('register-form');
    const status = document.getElementById('register-status');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      status.textContent = 'Memproses pendaftaran…';

      const name     = form.name.value.trim();
      const email    = form.email.value.trim();
      const password = form.password.value;

      try {
        const res = await StoryAPI.register({ name, email, password });
        if (res.error) {
          status.textContent = `Error: ${res.message}`;
        } else {
          status.textContent = 'Berhasil daftar! Redirecting…';
          // Setelah berhasil register, langsung ke login
          setTimeout(() => location.hash = '/login', 1000);
        }
      } catch {
        status.textContent = 'Gagal mendaftar.';
      }
    });
  }
}