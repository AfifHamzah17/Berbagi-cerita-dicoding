import { StoryAPI } from '../../data/api.js';

export default class LoginPage {
  async render() {
    return `
      <section class="container">
        <h1>Login</h1>
        <form id="login-form">
          <label for="email">Email</label>
          <input id="email" type="email" required />
          <label for="password">Password</label>
          <input id="password" type="password" required />
          <button type="submit">Masuk</button>
        </form>
        <div class="auth-switch">
            <button id="to-register">Belum punya akun? Daftar di sini</button>
        </div>
        <div id="login-status"></div>
      </section>
    `;
  }

  async afterRender() {
    document.getElementById('login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const status = document.getElementById('login-status');
      status.textContent = 'Memproses…';
      const email = e.target.email.value;
      const password = e.target.password.value;

      try {
        const res = await StoryAPI.login({ email, password });
        if (res.error) {
          status.textContent = `Error: ${res.message}`;
        } else {
          // login sukses, redirect ke beranda
          localStorage.setItem('token', res.loginResult.token);
          localStorage.setItem('userId', res.loginResult.userId);
          location.hash = '/';
        }
      } catch {
        status.textContent = 'Login gagal.';
      }
    });
  }
}