import { StoryAPI } from '../../data/api.js';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export default class DetailPage {
  constructor({ id }) {
    this.id = id;  // harus berupa 'story-XYZ'
  }

  async render() {
    return `
      <section class="container">
        <button id="btn-back">← Kembali</button>
        <div id="detail-content">Loading…</div>
      </section>
    `;
  }

  async afterRender() {
    document.getElementById('btn-back').addEventListener('click', () => history.back());
    const container = document.getElementById('detail-content');
    const token = localStorage.getItem('token');

    if (!this.id) {
      container.innerHTML = `<p>ID cerita tidak ditemukan.</p>`;
      return;
    }

    try {
      const { story, error, message } = await StoryAPI.getStoryDetail(this.id, token);
      if (error) {
        container.innerHTML = `<p>${message}</p>`;
        return;
      }

      container.innerHTML = `
        <h1>${story.name}</h1>
        <img src="${story.photoUrl}" alt="Foto oleh ${story.name}" />
        <p>${story.description}</p>
        <div id="map-detail" style="height:300px; margin:1rem 0;"></div>
      `;

      const map = L.map('map-detail').setView([story.lat, story.lon], 5);
      const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
      const topo = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png');
      osm.addTo(map);
      L.control.layers({ OSM: osm, Topo: topo }).addTo(map);
      L.marker([story.lat, story.lon]).addTo(map).bindPopup(story.name);
    } catch (err) {
      container.innerHTML = `<p>Gagal memuat detail cerita. ${err.message}</p>`;
    }
  }
}
