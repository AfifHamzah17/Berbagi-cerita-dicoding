// src/scripts/pages/home/home-page.js
import { StoryAPI } from '../../data/api.js';

export default class HomePage {
  async render() {
    return `
      <section class="container">
        <h1>Daftar Cerita</h1>
        <div id="story-list" class="story-list">Loading…</div>
      </section>
    `;
  }

  async afterRender() {
    const container = document.getElementById('story-list');
    const token = localStorage.getItem('token');

    try {
      const { listStory } = await StoryAPI.getStories({ location: 1 }, token);
      container.innerHTML = listStory.map(s => `
        <article class="story-card">
          <a href="#/detail/${s.id}">
            <img src="${s.photoUrl}" alt="Foto oleh ${s.name}" />
            <h2>${s.name}</h2>
            <p>${s.description.slice(0, 100)}…</p>
          </a>
        </article>
      `).join('');
    } catch {
      container.innerHTML = `<p>Gagal memuat cerita.</p>`;
    }
  }
}